/*Gafas*/

Item.defineArmor(500, "skull_zombie", 0, "Gafas oscuras", "armor/lentes.png", 3, 999, ArmorType.helment);

Item.defineArmor(501, "skull_creeper", 0, "Gafas", "mob/lentes2.png", 2, 999, ArmorType.helment);

Item.defineArmor(502, "skull_skeleton", 0, "Gafas 3D", "mob/lentes3.png", 3, 999, ArmorType.helment);

Item.defineArmor(503, "skull_steve", 0, "Gafas verdes", "armor/lentes6.png", 3, 999, ArmorType.helment);

Item.defineArmor(504, "ruby", 0, "Gafas azules", "armor/lentes4.png", 3, 999, ArmorType.helment);

Item.defineArmor(505, "skull_wither", 0, "Gafas amarillas", "armor/lentes5.png", 3, 999, ArmorType.helment);

Item.defineArmor(506, "record_strad", 0, "Gafas rojas", "armor/lentes7.png", 3, 999, ArmorType.helment);

Item.defineArmor(507, "record_13", 0, "Gafas moradas", "armor/lentes8.png", 3, 999, ArmorType.helment);

Item.defineArmor(508, "record_11", 0, "Gafas naranjas", "armor/lentes9.png", 3, 999, ArmorType.helment);

Item.defineArmor(509, "record_stal", 0, "Gafas cafes", "armor/lentes10.png", 3, 999, ArmorType.helment);

Item.defineArmor(510, "record_far", 0, "Gafas rosa", "armor/lentes11.png", 3, 999, ArmorType.helment);

Item.defineArmor(511, "record_wait", 0, "Gafas verde oscuras", "armor/lentes12.png", 3, 999, ArmorType.helment);

Item.defineArmor(512, "record_blocks", 0, "Gafas de oro", "armor/lentes13.png", 4, 999, ArmorType.helment);

Item.defineArmor(513, "record_cat", 0, "Gafas de diamante", "armor/lentes14.png", 6, 999, ArmorType.helment);

Item.defineArmor(514, "record_chirp", 0, "Gafas de hierro", "armor/lentes15.png", 5, 999, ArmorType.helment);

Item.defineArmor(515, "record_mall", 0, "Gafas de esmeralda", "armor/lentes16.png", 4, 999, ArmorType.helment);

Item.defineArmor(516, "record_mellohi", 0, "Gafas de lapiz", "armor/lentes17.png", 4, 999, ArmorType.helment);

Item.defineArmor(517, "record_ward", 0, "Gafas de redstone", "armor/lentes18.png", 4, 999, ArmorType.helment);

Item.defineArmor(518, "repeater", 0, "Pokegafas", "armor/lentes19.png", 4, 999, ArmorType.helment);

Item.defineArmor(519, "nether_star", 0, "Gafas de dinero", "armor/lentes20.png", 4, 999, ArmorType.helment);

Item.defineArmor(520, "nether_wart", 0, "Scouter", "armor/lentes21.png", 4, 999, ArmorType.helment);

Item.addShapedRecipe(502,1,0,["rrr","cbc","iii"],["r",351,1,"c",263,0,"b",501,0,"i",351,4]);

Item.addShapedRecipe(501,1,0,["rrr","cbc","iii"],["r",263,0,"c",20,0,"b",263,0,"i",263,0]);

Item.addShapedRecipe(500,1,0,[
"111",
"121",
"111"],["1",351,0,"2",501,0]);

Item.addShapedRecipe(503,1,0,[
"111",
"121",
"111"],["1",351,10,"2",501,0]);

Item.addShapedRecipe(504,1,0,[
"111",
"121",
"111"],["1",351,4,"2",501,0]);

Item.addShapedRecipe(505,1,0,[
"111",
"121",
"111"],["1",351,11,"2",501,0]);

Item.addShapedRecipe(506,1,0,[
"111",
"121",
"111"],["1",351,1,"2",501,0]);

Item.addShapedRecipe(507,1,0,[
"111",
"121",
"111"],["1",351,5,"2",501,0]);

Item.addShapedRecipe(508,1,0,[
"111",
"121",
"111"],["1",351,14,"2",501,0]);

Item.addShapedRecipe(509,1,0,[
"111",
"121",
"111"],["1",351,3,"2",501,0]);

Item.addShapedRecipe(510,1,0,[
"111",
"121",
"111"],["1",351,9,"2",501,0]);

Item.addShapedRecipe(511,1,0,[
"111",
"121",
"111"],["1",351,2,"2",501,0]);

Item.addShapedRecipe(512,1,0,["rrr","cbc","iii"],["r",266,0,"c",20,0,"b",266,0,"i",266,0]);

Item.addShapedRecipe(513,1,0,["rrr","cbc","iii"],["r",264,0,"c",20,0,"b",264,0,"i",264,0]);

Item.addShapedRecipe(514,1,0,["rrr","cbc","iii"],["r",265,0,"c",20,0,"b",265,0,"i",265,0]);

Item.addShapedRecipe(515,1,0,["rrr","cbc","iii"],["r",388,0,"c",20,0,"b",388,0,"i",388,0]);

Item.addShapedRecipe(516,1,0,["rrr","cbc","iii"],["r",351,4,"c",20,0,"b",351,4,"i",351,4]);

Item.addShapedRecipe(517,1,0,["rrr","cbc","iii"],["r",331,0,"c",20,0,"b",331,0,"i",331,0]);

Item.addShapedRecipe(518,1,0,["rrr","cbc","iii"],["r",331,0,"c",20,0,"b",263,0,"i",265,0]);

Item.addShapedRecipe(519,1,0,["rrr","cbc","iii"],["r",351,10,"c",263,0,"b",501,0,"i",351,2]);

Item.addShapedRecipe(520,1,0,["rrr","cbc","iii"],["r",351,10,"c",265,0,"b",102,0,"i",265,0]);

function useItem(x, y, z, itemId, blockId, side)
{

}

function attackHook(attacker, victim)
{

}

function modTick()
{

}

function procCmd(command)
{
var cmd = command.split(" ");

}

function newLevel()
{

}

function leaveGame()
{

}

